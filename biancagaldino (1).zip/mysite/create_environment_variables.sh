export FLASK_APP=flasky.py
export FLASK_DEBUG=1
export MAIL_USERNAME=flaskaulas@zohomail.com
export MAIL_PASSWORD=$1
export FLASKY_ADMIN=fabio.teixeira@ifsp.edu.br
export FLASKY_CONFIG=DevelopmentConfig